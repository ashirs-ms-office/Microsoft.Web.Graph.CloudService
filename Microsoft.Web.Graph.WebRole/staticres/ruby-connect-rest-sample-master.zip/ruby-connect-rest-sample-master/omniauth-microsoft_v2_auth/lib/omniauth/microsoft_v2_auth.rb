require "omniauth/microsoft_v2_auth/version"
require "omniauth/strategies/microsoft_v2_auth"
