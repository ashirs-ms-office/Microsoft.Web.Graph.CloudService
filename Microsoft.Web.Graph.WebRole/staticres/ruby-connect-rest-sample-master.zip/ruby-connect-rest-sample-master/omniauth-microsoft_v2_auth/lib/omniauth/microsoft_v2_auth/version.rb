module Omniauth
  module MicrosoftV2Auth
    VERSION = "0.1.0"
  end
end
