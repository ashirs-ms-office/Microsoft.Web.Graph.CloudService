require 'omniauth/microsoft_v2_auth'
