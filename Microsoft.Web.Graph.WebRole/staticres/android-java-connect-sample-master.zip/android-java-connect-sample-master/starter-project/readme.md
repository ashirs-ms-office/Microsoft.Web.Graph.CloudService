# Microsoft Graph Starter project for Android
This is the starter project used by the Android walkthrough in the [Microsoft Graph documentation](http://graph.microsoft.io).

This project has the following features already configured so you can focus on the code:

* Basic Android Studio project structure
* Dependency on required libraries
* Basic UI
* Internet permissions for the app
* Intent filter required for MainActivity
 
## Copyright
Copyright (c) 2016 Microsoft. All rights reserved.
