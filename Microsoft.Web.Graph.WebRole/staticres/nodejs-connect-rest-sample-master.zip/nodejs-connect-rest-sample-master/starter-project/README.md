# Office 365 Node.js Connect starter project
This is the starter project used by the Node.js walkthrough in the [Microsoft Graph documentation](http://graph.microsoft.io). 

## Copyright
Copyright (c) 2016 Microsoft. All rights reserved.
