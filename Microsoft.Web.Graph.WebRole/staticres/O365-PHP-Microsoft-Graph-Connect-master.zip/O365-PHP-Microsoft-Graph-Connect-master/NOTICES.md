This project uses the following third-party components:

PHP, which is Copyright (c) The PHP Group and is available under the [PHP License, Version 3.01](http://www.php.net/license/3_01.txt).

cURL, which is Copyright (c) Daniel Stenberg and is available under the [cURL license](http://curl.haxx.se/docs/copyright.html).