/* 
*  Copyright (c) Microsoft. All rights reserved. Licensed under the MIT license. 
*  See LICENSE in the source repository root for complete license information. 
*/

var clientId = "ENTER_YOUR_CLIENT_ID";
var redirectUrl = "http://localhost:8080/login";
var graphScopes = "user.read mail.send";