This project includes the following third-party components:


Microsoft Azure Active Directory Authentication Library (ADAL) for Android, which is Copyright (c) Microsoft Open Technologies, Inc., and is available under the [Apache License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0).  Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an "AS IS" BASIS WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.

Android SDK, which is provided by the Android Open Source Project and is used according to terms described in the [Creative Commons 2.5 Attribution License](http://creativecommons.org/licenses/by/2.5/). The Android SDK is available at [http://developer.android.com/sdk/index.html](http://developer.android.com/sdk/index.html).
